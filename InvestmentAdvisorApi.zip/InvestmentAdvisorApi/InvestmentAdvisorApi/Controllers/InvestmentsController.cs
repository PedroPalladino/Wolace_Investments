﻿using Microsoft.AspNetCore.Mvc;
using InvestmentPortfolioAPI.Models;
using InvestmentPortfolioAPI.Data;
using InvestmentPortfolioAPI.Services;
using Microsoft.EntityFrameworkCore;

namespace InvestmentPortfolioAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvestmentsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly PortfolioService _portfolioService;
        private readonly ILogger<InvestmentsController> _logger;

        public InvestmentsController(
            AppDbContext context,
            PortfolioService portfolioService,
            ILogger<InvestmentsController> logger)
        {
            _context = context;
            _portfolioService = portfolioService;
            _logger = logger;
        }

        // GET: api/Investments
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Investment>>> GetInvestments()
        {
            try
            {
                var investments = await _context.Investments.ToListAsync();
                return Ok(investments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all investments");
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/Investments/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Investment>> GetInvestment(int id)
        {
            try
            {
                var investment = await _context.Investments.FindAsync(id);

                if (investment == null)
                {
                    return NotFound();
                }

                return investment;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting investment with ID: {Id}", id);
                return StatusCode(500, "Internal server error");
            }
        }

        // PUT: api/Investments/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutInvestment(int id, Investment investment)
        {
            if (id != investment.Id)
            {
                return BadRequest();
            }

            try
            {
                investment.LastUpdated = DateTime.UtcNow;
                _context.Entry(investment).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (DbUpdateConcurrencyException ex)
            {
                if (!InvestmentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    _logger.LogError(ex, "Concurrency error updating investment with ID: {Id}", id);
                    return StatusCode(500, "Concurrency error");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating investment with ID: {Id}", id);
                return StatusCode(500, "Internal server error");
            }
        }

        // POST: api/Investments
        [HttpPost]
        public async Task<ActionResult<Investment>> PostInvestment(Investment investment)
        {
            try
            {
                investment.LastUpdated = DateTime.UtcNow;
                _context.Investments.Add(investment);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetInvestment", new { id = investment.Id }, investment);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating new investment");
                return StatusCode(500, "Internal server error");
            }
        }

        // DELETE: api/Investments/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInvestment(int id)
        {
            try
            {
                var investment = await _context.Investments.FindAsync(id);
                if (investment == null)
                {
                    return NotFound();
                }

                _context.Investments.Remove(investment);
                await _context.SaveChangesAsync();

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting investment with ID: {Id}", id);
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/Investments/type/{type}
        [HttpGet("type/{type}")]
        public async Task<ActionResult<IEnumerable<Investment>>> GetInvestmentsByType(string type)
        {
            try
            {
                var investments = await _portfolioService.GetInvestmentsByType(type);
                return Ok(investments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting investments by type: {Type}", type);
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/Investments/high-return/{minReturn}
        [HttpGet("high-return/{minReturn}")]
        public async Task<ActionResult<IEnumerable<Investment>>> GetHighReturnInvestments(decimal minReturn)
        {
            try
            {
                var investments = await _portfolioService.GetHighReturnInvestments(minReturn);
                return Ok(investments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting high return investments with min return: {MinReturn}", minReturn);
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/Investments/low-risk/{maxRisk}
        [HttpGet("low-risk/{maxRisk}")]
        public async Task<ActionResult<IEnumerable<Investment>>> GetLowRiskInvestments(decimal maxRisk)
        {
            try
            {
                var investments = await _portfolioService.GetLowRiskInvestments(maxRisk);
                return Ok(investments);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting low risk investments with max risk: {MaxRisk}", maxRisk);
                return StatusCode(500, "Internal server error");
            }
        }

        private bool InvestmentExists(int id)
        {
            return _context.Investments.Any(e => e.Id == id);
        }
    }
}