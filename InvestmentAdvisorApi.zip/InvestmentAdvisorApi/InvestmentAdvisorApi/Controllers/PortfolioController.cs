﻿using Microsoft.AspNetCore.Mvc;
using InvestmentPortfolioAPI.Services;
using InvestmentPortfolioAPI.Models;

namespace InvestmentPortfolioAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PortfolioController : ControllerBase
    {
        private readonly PortfolioService _portfolioService;
        private readonly ILogger<PortfolioController> _logger;

        public PortfolioController(PortfolioService portfolioService, ILogger<PortfolioController> logger)
        {
            _portfolioService = portfolioService;
            _logger = logger;
        }

        // GET: api/Portfolio/recommendation/{riskProfile}
        [HttpGet("recommendation/{riskProfile}")]
        public async Task<ActionResult<PortfolioRecommendation>> GetPortfolioRecommendation(string riskProfile)
        {
            try
            {
                if (string.IsNullOrEmpty(riskProfile) ||
                    (riskProfile.ToLower() != "conservative" &&
                     riskProfile.ToLower() != "moderate" &&
                     riskProfile.ToLower() != "aggressive"))
                {
                    return BadRequest("Risk profile must be 'conservative', 'moderate', or 'aggressive'");
                }

                var recommendation = await _portfolioService.GeneratePortfolioRecommendation(riskProfile);
                return Ok(recommendation);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating portfolio recommendation for risk profile: {RiskProfile}", riskProfile);
                return StatusCode(500, "Internal server error");
            }
        }

        // GET: api/Portfolio/history
        [HttpGet("history")]
        public async Task<ActionResult<List<PortfolioRecommendation>>> GetRecommendationHistory()
        {
            try
            {
                var history = await _portfolioService.GetRecommendationHistory();
                return Ok(history);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting recommendation history");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}