﻿using Microsoft.EntityFrameworkCore;
using InvestmentPortfolioAPI.Models;

namespace InvestmentPortfolioAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Investment> Investments { get; set; }
        public DbSet<PortfolioRecommendation> PortfolioRecommendations { get; set; }
        public DbSet<PortfolioItem> PortfolioItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships
            modelBuilder.Entity<PortfolioRecommendation>()
                .HasMany(pr => pr.Recommendations)
                .WithOne(pi => pi.PortfolioRecommendation)
                .HasForeignKey(pi => pi.PortfolioRecommendationId)
                .OnDelete(DeleteBehavior.Cascade);

            // Seed initial data
            modelBuilder.Entity<Investment>().HasData(
                new Investment
                {
                    Id = 1,
                    Name = "Apple Inc.",
                    Type = "Stock",
                    CurrentPrice = 150.50m,
                    ExpectedReturn = 8.5m,
                    RiskLevel = 7,
                    LastUpdated = DateTime.UtcNow
                },
                new Investment
                {
                    Id = 2,
                    Name = "Microsoft Corp.",
                    Type = "Stock",
                    CurrentPrice = 280.75m,
                    ExpectedReturn = 9.2m,
                    RiskLevel = 6,
                    LastUpdated = DateTime.UtcNow
                },
                new Investment
                {
                    Id = 3,
                    Name = "US Treasury Bond",
                    Type = "Bond",
                    CurrentPrice = 1000.00m,
                    ExpectedReturn = 3.5m,
                    RiskLevel = 2,
                    LastUpdated = DateTime.UtcNow
                },
                new Investment
                {
                    Id = 4,
                    Name = "Bitcoin",
                    Type = "Crypto",
                    CurrentPrice = 35000.00m,
                    ExpectedReturn = 15.0m,
                    RiskLevel = 9,
                    LastUpdated = DateTime.UtcNow
                },
                new Investment
                {
                    Id = 5,
                    Name = "Amazon Inc.",
                    Type = "Stock",
                    CurrentPrice = 3200.00m,
                    ExpectedReturn = 10.5m,
                    RiskLevel = 8,
                    LastUpdated = DateTime.UtcNow
                }
            );
        }
    }
}