﻿using System.ComponentModel.DataAnnotations;

namespace InvestmentPortfolioAPI.Models
{
    public class Investment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string Type { get; set; } = string.Empty; // Stock, Bond, Crypto, etc.

        [Range(0, double.MaxValue)]
        public decimal CurrentPrice { get; set; }

        [Range(0, 100)]
        public decimal ExpectedReturn { get; set; }

        [Range(1, 10)]
        public decimal RiskLevel { get; set; } // 1-10 scale

        public DateTime LastUpdated { get; set; }
    }
}