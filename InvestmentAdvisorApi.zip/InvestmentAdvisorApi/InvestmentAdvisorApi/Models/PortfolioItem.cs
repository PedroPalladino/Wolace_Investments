﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InvestmentPortfolioAPI.Models
{
    public class PortfolioItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string InvestmentName { get; set; } = string.Empty;

        [Range(0, 100)]
        public decimal Percentage { get; set; }

        public string Reason { get; set; } = string.Empty;

        // Foreign key
        public int PortfolioRecommendationId { get; set; }

        [ForeignKey("PortfolioRecommendationId")]
        public PortfolioRecommendation PortfolioRecommendation { get; set; } = null!;
    }
}