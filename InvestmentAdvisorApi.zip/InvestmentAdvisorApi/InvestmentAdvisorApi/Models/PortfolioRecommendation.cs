﻿using System.ComponentModel.DataAnnotations;

namespace InvestmentPortfolioAPI.Models
{
    public class PortfolioRecommendation
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(20)]
        public string RiskProfile { get; set; } = string.Empty; // Conservative, Moderate, Aggressive

        public List<PortfolioItem> Recommendations { get; set; } = new List<PortfolioItem>();

        public DateTime GeneratedDate { get; set; }
    }
}