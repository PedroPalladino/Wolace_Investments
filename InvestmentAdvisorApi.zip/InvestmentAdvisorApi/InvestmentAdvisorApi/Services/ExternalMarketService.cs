﻿using System.Text.Json;
using InvestmentPortfolioAPI.Models;

namespace InvestmentPortfolioAPI.Services
{
    public class ExternalMarketService : IExternalMarketService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<ExternalMarketService> _logger;

        public ExternalMarketService(HttpClient httpClient, ILogger<ExternalMarketService> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
            _httpClient.BaseAddress = new Uri("https://api.mocki.io/v2/");
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "InvestmentPortfolioAPI");
        }

        public async Task<decimal> GetCurrentPriceAsync(string symbol)
        {
            try
            {
                // Simulação de API externa
                await Task.Delay(100); // Simula latência de rede

                // Retorna um preço aleatório entre 50 e 5000 para demonstração
                var random = new Random();
                return Math.Round((decimal)(random.NextDouble() * 4950 + 50), 2);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching current price for {Symbol}", symbol);
                return 0;
            }
        }

        public async Task<List<Investment>> GetMarketDataAsync()
        {
            try
            {
                // Simulação de dados de mercado externos
                await Task.Delay(200); // Simula latência de rede

                return new List<Investment>
                {
                    new Investment
                    {
                        Name = "Google (GOOGL)",
                        Type = "Stock",
                        CurrentPrice = 2750.00m,
                        ExpectedReturn = 12.5m,
                        RiskLevel = 7,
                        LastUpdated = DateTime.UtcNow
                    },
                    new Investment
                    {
                        Name = "Tesla (TSLA)",
                        Type = "Stock",
                        CurrentPrice = 850.00m,
                        ExpectedReturn = 18.0m,
                        RiskLevel = 9,
                        LastUpdated = DateTime.UtcNow
                    },
                    new Investment
                    {
                        Name = "Gold ETF (GLD)",
                        Type = "Commodity",
                        CurrentPrice = 180.00m,
                        ExpectedReturn = 5.0m,
                        RiskLevel = 4,
                        LastUpdated = DateTime.UtcNow
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching market data");
                return new List<Investment>();
            }
        }
    }
}