﻿using InvestmentPortfolioAPI.Models;

namespace InvestmentPortfolioAPI.Services
{
    public interface IExternalMarketService
    {
        Task<decimal> GetCurrentPriceAsync(string symbol);
        Task<List<Investment>> GetMarketDataAsync();
    }
}