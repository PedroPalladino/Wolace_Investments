﻿using InvestmentPortfolioAPI.Models;
using InvestmentPortfolioAPI.Data;
using Microsoft.EntityFrameworkCore;

namespace InvestmentPortfolioAPI.Services
{
    public class PortfolioService
    {
        private readonly AppDbContext _context;
        private readonly IExternalMarketService _marketService;
        private readonly ILogger<PortfolioService> _logger;

        public PortfolioService(AppDbContext context, IExternalMarketService marketService, ILogger<PortfolioService> logger)
        {
            _context = context;
            _marketService = marketService;
            _logger = logger;
        }

        public async Task<PortfolioRecommendation> GeneratePortfolioRecommendation(string riskProfile)
        {
            try
            {
                _logger.LogInformation("Generating portfolio recommendation for risk profile: {RiskProfile}", riskProfile);

                var investments = await _context.Investments.ToListAsync();
                var externalInvestments = await _marketService.GetMarketDataAsync();

                investments.AddRange(externalInvestments);

                var recommendation = new PortfolioRecommendation
                {
                    RiskProfile = riskProfile,
                    GeneratedDate = DateTime.UtcNow
                };

                var filteredInvestments = riskProfile.ToLower() switch
                {
                    "conservative" => investments.Where(i => i.RiskLevel <= 4)
                                                .OrderByDescending(i => i.ExpectedReturn / i.RiskLevel),
                    "moderate" => investments.Where(i => i.RiskLevel > 4 && i.RiskLevel <= 7)
                                           .OrderByDescending(i => i.ExpectedReturn),
                    "aggressive" => investments.Where(i => i.RiskLevel > 7)
                                             .OrderByDescending(i => i.ExpectedReturn),
                    _ => investments.OrderBy(i => i.RiskLevel)
                };

                var topInvestments = filteredInvestments.Take(5).ToList();

                if (!topInvestments.Any())
                {
                    _logger.LogWarning("No investments found for risk profile: {RiskProfile}", riskProfile);
                    return recommendation;
                }

                var totalWeight = topInvestments.Sum(i => i.ExpectedReturn);

                foreach (var investment in topInvestments)
                {
                    var percentage = totalWeight > 0 ? (investment.ExpectedReturn / totalWeight) * 100 : 0;

                    var portfolioItem = new PortfolioItem
                    {
                        InvestmentName = investment.Name,
                        Percentage = Math.Round(percentage, 2),
                        Reason = $"Expected return: {investment.ExpectedReturn}%, Risk: {investment.RiskLevel}/10"
                    };

                    recommendation.Recommendations.Add(portfolioItem);
                }

                _context.PortfolioRecommendations.Add(recommendation);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Portfolio recommendation generated successfully for {RiskProfile}", riskProfile);
                return recommendation;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating portfolio recommendation for {RiskProfile}", riskProfile);
                throw;
            }
        }

        // LINQ Queries para pesquisa
        public async Task<List<Investment>> GetInvestmentsByType(string type)
        {
            return await _context.Investments
                .Where(i => i.Type.ToLower() == type.ToLower())
                .OrderByDescending(i => i.ExpectedReturn)
                .ToListAsync();
        }

        public async Task<List<Investment>> GetHighReturnInvestments(decimal minReturn)
        {
            return await _context.Investments
                .Where(i => i.ExpectedReturn >= minReturn)
                .OrderByDescending(i => i.ExpectedReturn)
                .ToListAsync();
        }

        public async Task<List<Investment>> GetLowRiskInvestments(decimal maxRisk)
        {
            return await _context.Investments
                .Where(i => i.RiskLevel <= maxRisk)
                .OrderBy(i => i.RiskLevel)
                .ThenByDescending(i => i.ExpectedReturn)
                .ToListAsync();
        }

        public async Task<List<PortfolioRecommendation>> GetRecommendationHistory()
        {
            return await _context.PortfolioRecommendations
                .Include(pr => pr.Recommendations)
                .OrderByDescending(pr => pr.GeneratedDate)
                .Take(10)
                .ToListAsync();
        }
    }
}